const express = require('express');
const axios = require('axios');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const BACKEND_URL = process.env.BACKEND_URL || 'http://backend:5000';

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Serve the main HTML form
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Proxy form submission from Express frontend to Flask backend
app.post('/submit', async (req, res) => {
    try {
        const response = await axios.post(`${BACKEND_URL}/api/submit`, req.body);
        res.status(response.status).json(response.data);
    } catch (error) {
        const status = error.response ? error.response.status : 500;
        const message = error.response
            ? error.response.data
            : { success: false, error: 'Unable to reach Flask backend service.' };
        res.status(status).json(message);
    }
});

// Fetch all submissions from Flask backend
app.get('/submissions', async (req, res) => {
    try {
        const response = await axios.get(`${BACKEND_URL}/api/submissions`);
        res.status(200).json(response.data);
    } catch (error) {
        res.status(500).json({ success: false, error: 'Failed to retrieve submissions.' });
    }
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Express Frontend running on http://0.0.0.0:${PORT}`);
    console.log(`Connected to Flask Backend at ${BACKEND_URL}`);
});
