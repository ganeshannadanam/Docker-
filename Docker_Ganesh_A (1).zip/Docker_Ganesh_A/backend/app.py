from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# In-memory storage for submitted entries
submissions = []

@app.route('/', methods=['GET'])
def health_check():
    return jsonify({
        "status": "running",
        "service": "Flask Backend API",
        "total_submissions": len(submissions)
    }), 200

@app.route('/api/submit', methods=['POST'])
def submit_form():
    data = request.get_json() if request.is_json else request.form.to_dict()
    
    name = data.get('name', '').strip()
    email = data.get('email', '').strip()
    course = data.get('course', '').strip()
    message = data.get('message', '').strip()

    if not name or not email:
        return jsonify({
            "success": False,
            "error": "Name and Email are required fields."
        }), 400

    entry = {
        "id": len(submissions) + 1,
        "name": name,
        "email": email,
        "course": course or "DevOps with Docker",
        "message": message
    }
    submissions.append(entry)

    return jsonify({
        "success": True,
        "message": f"Thank you, {name}! Your form submission has been processed by the Flask backend.",
        "data": entry
    }), 201

@app.route('/api/submissions', methods=['GET'])
def get_submissions():
    return jsonify({
        "success": True,
        "count": len(submissions),
        "submissions": submissions
    }), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
