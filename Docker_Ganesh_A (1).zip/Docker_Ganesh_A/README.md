# DevOps Docker Assignment — Full-Stack Containerization

**Submitted By:** Ganesh A  
**GitHub Repository:** https://github.com/ganeshannadanam/Docker-  
**Docker Hub Images:**
- `ganeshannadanam/flask-backend:latest`
- `ganeshannadanam/express-frontend:latest`

## Project Structure
```text
Docker_Ganesh_A/
├── backend/
│   ├── app.py
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── views/
│   │   └── index.html
│   ├── package.json
│   ├── server.js
│   └── Dockerfile
├── screenshots/
├── docker-compose.yaml
├── .gitignore
├── README.md
└── Docker_Assignment_Documentation_Ganesh_A.docx
```

## Quick Start with Docker Compose
```bash
docker compose up --build -d
```
- **Frontend UI:** http://localhost:3000
- **Backend API:** http://localhost:5000
